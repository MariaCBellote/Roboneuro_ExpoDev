import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';

export default function Inicio({ navigation }) {
  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.sair} onPress={() => navigation.goBack()}>
        <Text style={styles.buttonText}>Sair</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Robôneuro</Text>

      <Text style={styles.welcome}>Bem-vindo!</Text>

      <Text style={styles.text}>Jogos</Text>
      <Text style={styles.text}>Atividades</Text>
      <Text style={styles.text}>Meu Robô</Text>
      <Text style={styles.text}>Progresso</Text>
      <Text style={styles.text}>Configurações</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF1D4',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },

  sair: {
    position: 'absolute',
    top: 50,
    right: 20,
    backgroundColor: '#FF6B6B',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 15,
  },

  buttonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },

  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#FF6B6B',
    marginBottom: 20,
  },

  welcome: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
  },

  text: {
    fontSize: 20,
    marginTop: 10,
    color: '#555',
  },
});
