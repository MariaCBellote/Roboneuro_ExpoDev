import React, { useState } from 'react';

import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TouchableOpacity,
  Switch,
  StyleSheet,
} from 'react-native';

export default function Configuracoes({ navigation }) {
  const [sons, setSons] = useState(true);
  const [animacoes, setAnimacoes] = useState(true);
  const [notificacoes, setNotificacoes] = useState(true);
  const [modoResponsavel, setModoResponsavel] = useState(false);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>

        <Text style={styles.title}>
          Configurações
        </Text>

        <Text style={styles.subtitle}>
          Ajuste o aplicativo da forma que preferir
        </Text>

        {/* CONFIGURAÇÕES DA CRIANÇA */}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            Preferências
          </Text>

          <View style={styles.configCard}>
            <View style={styles.textArea}>
              <Text style={styles.configTitle}>
                Sons
              </Text>

              <Text style={styles.description}>
                Ativar ou desativar os sons do aplicativo.
              </Text>
            </View>

            <Switch
              value={sons}
              onValueChange={setSons}
              trackColor={{
                false: '#ddd',
                true: '#FFD166',
              }}
              thumbColor={sons ? '#FF6B6B' : '#f4f3f4'}
            />
          </View>

          <View style={styles.configCard}>
            <View style={styles.textArea}>
              <Text style={styles.configTitle}>
                Animações
              </Text>

              <Text style={styles.description}>
                Ativar ou desativar as animações da aplicação.
              </Text>
            </View>

            <Switch
              value={animacoes}
              onValueChange={setAnimacoes}
              trackColor={{
                false: '#ddd',
                true: '#FFD166',
              }}
              thumbColor={animacoes ? '#FF6B6B' : '#f4f3f4'}
            />
          </View>

          <View style={styles.configCard}>
            <View style={styles.textArea}>
              <Text style={styles.configTitle}>
                Notificações
              </Text>

              <Text style={styles.description}>
                Receber avisos e lembretes do aplicativo.
              </Text>
            </View>

            <Switch
              value={notificacoes}
              onValueChange={setNotificacoes}
              trackColor={{
                false: '#ddd',
                true: '#FFD166',
              }}
              thumbColor={notificacoes ? '#FF6B6B' : '#f4f3f4'}
            />
          </View>
        </View>

        {/* CONFIGURAÇÕES DO USUÁRIO */}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            Conta
          </Text>

          <View style={styles.infoCard}>
            <Text style={styles.configTitle}>
              Nome do usuário
            </Text>

            <Text style={styles.description}>
              Alterar o nome utilizado no aplicativo.
            </Text>

            <TouchableOpacity
              style={styles.smallButton}
              activeOpacity={0.8}
            >
              <Text style={styles.smallButtonText}>
                Alterar nome
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.configTitle}>
              Senha
            </Text>

            <Text style={styles.description}>
              Alterar a senha da conta.
            </Text>

            <TouchableOpacity
              style={styles.smallButton}
              activeOpacity={0.8}
            >
              <Text style={styles.smallButtonText}>
                Alterar senha
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* CONFIGURAÇÕES DOS RESPONSÁVEIS */}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>
            Responsáveis
          </Text>

          <View style={styles.configCard}>
            <View style={styles.textArea}>
              <Text style={styles.configTitle}>
                Modo responsável
              </Text>

              <Text style={styles.description}>
                Permite acessar informações e configurações destinadas aos responsáveis.
              </Text>
            </View>

            <Switch
              value={modoResponsavel}
              onValueChange={setModoResponsavel}
              trackColor={{
                false: '#ddd',
                true: '#FFD166',
              }}
              thumbColor={
                modoResponsavel ? '#FF6B6B' : '#f4f3f4'
              }
            />
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.configTitle}>
              Acompanhamento
            </Text>

            <Text style={styles.description}>
              Visualizar o progresso e as atividades realizadas.
            </Text>

            <TouchableOpacity
              style={styles.smallButton}
              activeOpacity={0.8}
            >
              <Text style={styles.smallButtonText}>
                Ver informações
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.configTitle}>
              Tempo de uso
            </Text>

            <Text style={styles.description}>
              Definir limites e horários para utilização do aplicativo.
            </Text>

            <TouchableOpacity
              style={styles.smallButton}
              activeOpacity={0.8}
            >
              <Text style={styles.smallButtonText}>
                Configurar
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <TouchableOpacity
          style={styles.voltar}
          onPress={() => navigation.goBack()}
          activeOpacity={0.8}
        >
          <Text style={styles.voltarText}>
            Voltar
          </Text>
        </TouchableOpacity>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF1D4',
  },

  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FF6B6B',
    textAlign: 'center',
    marginTop: 20,
  },

  subtitle: {
    fontSize: 17,
    color: '#666',
    textAlign: 'center',
    marginTop: 8,
    marginBottom: 25,
    paddingHorizontal: 20,
  },

  section: {
    marginHorizontal: 20,
    marginBottom: 20,
  },

  sectionTitle: {
    fontSize: 21,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },

  configCard: {
    backgroundColor: '#FFF9ED',
    borderWidth: 2,
    borderColor: '#FFD166',
    borderRadius: 16,
    padding: 16,
    marginBottom: 10,

    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  infoCard: {
    backgroundColor: '#FFF9ED',
    borderWidth: 2,
    borderColor: '#FFD166',
    borderRadius: 16,
    padding: 16,
    marginBottom: 10,
  },

  textArea: {
    flex: 1,
    marginRight: 15,
  },

  configTitle: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#333',
  },

  description: {
    fontSize: 14,
    color: '#666',
    marginTop: 5,
    lineHeight: 20,
  },

  smallButton: {
    backgroundColor: '#FF6B6B',
    alignSelf: 'flex-start',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 10,
    marginTop: 12,
  },

  smallButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: 'bold',
  },

  voltar: {
    backgroundColor: '#FF6B6B',
    marginHorizontal: 20,
    marginTop: 5,
    marginBottom: 30,
    paddingVertical: 15,
    borderRadius: 15,
    alignItems: 'center',
  },

  voltarText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});