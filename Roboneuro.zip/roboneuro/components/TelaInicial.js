import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
} from 'react-native';

export default function Inicio({ navigation }) {
  return (
    <SafeAreaView style={styles.container}>

      {/* Botão sair */}
      <TouchableOpacity
        style={styles.sair}
        onPress={() => navigation.goBack()}
        activeOpacity={0.8}
      >
        <Text style={styles.sairText}>
          Sair
        </Text>
      </TouchableOpacity>

      {/* Cabeçalho */}
      <ScrollView showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.robot}>
          🤖
        </Text>

        <Text style={styles.title}>
          Robôneuro
        </Text>

        <Text style={styles.welcome}>
          Bem-vindo!
        </Text>

        <Text style={styles.subtitle}>
          O que você quer fazer hoje?
        </Text>
      </View>

      {/* Menu */}
      <View style={styles.menu}>

        <TouchableOpacity
          style={styles.menuButton}
          onPress={() => navigation.navigate('Jogos')}
          activeOpacity={0.8}
        >
          <Text style={styles.menuEmoji}>🎮</Text>
          <Text style={styles.menuText}>Jogos</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuButton}
          onPress={() => navigation.navigate('Atividades')}
          activeOpacity={0.8}
        >
          <Text style={styles.menuEmoji}>🧩</Text>
          <Text style={styles.menuText}>Atividades</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuButton}
          onPress={() => navigation.navigate('MeuRobo')}
          activeOpacity={0.8}
        >
          <Text style={styles.menuEmoji}>🤖</Text>
          <Text style={styles.menuText}>Meu Robô</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuButton}
          onPress={() => navigation.navigate('Progresso')}
          activeOpacity={0.8}
        >
          <Text style={styles.menuEmoji}>⭐</Text>
          <Text style={styles.menuText}>Progresso</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuButton}
          onPress={() => navigation.navigate('Configuracoes')}
          activeOpacity={0.8}
        >
          <Text style={styles.menuEmoji}>⚙️</Text>
          <Text style={styles.menuText}>Configurações</Text>
        </TouchableOpacity>

      </View>
     </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF1D4',
    paddingHorizontal: 20,
  },

  sair: {
    alignSelf: 'center',
    backgroundColor: '#FF6B6B',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 15,
    marginTop: 15,
  },

  sairText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: 'bold',
    
  },

  header: {
    alignItems: 'center',
    marginTop: 15,
    marginBottom: 25,
  },

  robot: {
    fontSize: 52,
    marginBottom: 5,
  },

  title: {
    fontSize: 34,
    fontWeight: 'bold',
    color: '#FF6B6B',
    marginBottom: 5,
  },

  welcome: {
    fontSize: 25,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },

  subtitle: {
    fontSize: 17,
    color: '#666',
    textAlign: 'center',
  },

  menu: {
    width: '100%',
  },

  menuButton: {
    backgroundColor: '#FFFFFF',
    borderWidth: 2,
    borderColor: '#FFD166',
    borderRadius: 18,
    paddingVertical: 16,
    paddingHorizontal: 20,
    marginBottom: 14,

    flexDirection: 'row',
    alignItems: 'center',
  },

  menuEmoji: {
    fontSize: 28,
    width: 45,
    textAlign: 'center',
  },

  menuText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#444',
    marginLeft: 12,
  },
});