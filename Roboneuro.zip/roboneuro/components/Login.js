import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

export default function Login({ navigation }) {
  const [nome, setNome] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');

  const entrar = () => {
    const nomeLimpo = nome.trim();
    const senhaLimpa = senha.trim();

    setErro('');

    if (nomeLimpo === '' || senhaLimpa === '') {
      setErro('Preencha o nome e a senha.');
      return;
    }

    if (!/[A-Za-zÀ-ÿ]/.test(nomeLimpo)) {
      setErro('O nome não pode conter somente números.');
      return;
    }

    navigation.navigate('Inicio');
  };

  return (
    <View style={styles.container}>

      <View style={styles.card}>

        <Text style={styles.emoji}>
          🤖
        </Text>

        <Text style={styles.title}>
          Robôneuro
        </Text>

        <Text style={styles.subtitle}>
          Entre na sua conta!
        </Text>

        <Text style={styles.label}>
          Nome
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Digite seu nome"
          placeholderTextColor="#999"
          value={nome}
          onChangeText={setNome}
        />

        <Text style={styles.label}>
          Senha
        </Text>

        <TextInput
          style={styles.input}
          placeholder="Digite sua senha"
          placeholderTextColor="#999"
          secureTextEntry={true}
          value={senha}
          onChangeText={setSenha}
        />

        <TouchableOpacity
          style={styles.button}
          onPress={entrar}
          activeOpacity={0.8}
        >
          <Text style={styles.buttonText}>
            Entrar
          </Text>
        </TouchableOpacity>

        {erro !== '' && (
          <View style={styles.erroContainer}>
            <Text style={styles.erro}>
              {erro}
            </Text>
          </View>
        )}

      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF1D4',
    justifyContent: 'center',
    padding: 20,
  },

  card: {
    backgroundColor: '#FFF9ED',
    borderRadius: 25,
    padding: 25,
    elevation: 5,

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.12,
    shadowRadius: 6,
  },

  emoji: {
    fontSize: 48,
    textAlign: 'center',
    marginBottom: 5,
  },

  title: {
    fontSize: 34,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#FF6B6B',
    marginBottom: 8,
  },

  subtitle: {
    fontSize: 20,
    textAlign: 'center',
    color: '#555',
    marginBottom: 30,
  },

  label: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#444',
    marginBottom: 7,
  },

  input: {
    backgroundColor: '#FFFFFF',
    borderWidth: 2,
    borderColor: '#FFD166',
    borderRadius: 14,
    padding: 15,
    fontSize: 17,
    marginBottom: 18,
  },

  button: {
    backgroundColor: '#FF6B6B',
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
    marginTop: 5,
  },

  buttonText: {
    color: '#FFFFFF',
    fontSize: 19,
    fontWeight: 'bold',
  },

  erroContainer: {
    backgroundColor: '#FFE0E0',
    borderRadius: 10,
    padding: 12,
    marginTop: 15,
    borderWidth: 1,
    borderColor: '#FF6B6B',
  },

  erro: {
    color: '#C62828',
    fontSize: 15,
    textAlign: 'center',
    fontWeight: '600',
  },
});