import React, { useState } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';

export default function Progresso({ navigation }) {
  // Estado do Robô (Nível e Experiência)
  const [nivel, setNivel] = useState(1);
  const [xp, setXp] = useState(0); // 0 a 100 XP por nível
  const [mensagem, setMensagem] = useState(
    'Olá! Faça atividades para liberarmos novas brincadeiras!'
  );

  // Lista de ações e em qual nível elas são liberadas
  const acoes = [
    {
      id: 1,
      nivelRequerido: 1,
      titulo: 'Acenar',
      icone: '👋',
      resposta: 'Oi! Que bom ver você!',
    },
    {
      id: 2,
      nivelRequerido: 1,
      titulo: 'Sorrir',
      icone: '😊',
      resposta: 'Estou muito feliz hoje!',
    },
    {
      id: 3,
      nivelRequerido: 2,
      titulo: 'Cantar',
      icone: '🎵',
      resposta: 'Lá lá lá! Vamos cantar juntos!',
    },
    {
      id: 4,
      nivelRequerido: 3,
      titulo: 'Conversar',
      icone: '💬',
      resposta: 'Como foi o seu dia hoje?',
    },
    {
      id: 5,
      nivelRequerido: 4,
      titulo: 'Dançar',
      icone: '💃',
      resposta: 'Olha os meus passos de dança!',
    },
    {
      id: 6,
      nivelRequerido: 5,
      titulo: 'Piada Secreta',
      icone: '🤪',
      resposta: 'O que o robô falou pro computador? Você é meu amigo de bits!',
    },
  ];

  // Função para lidar com o clique na ação
  const executarAcao = (acao) => {
    // Se a ação está bloqueada pelo nível
    if (nivel < acao.nivelRequerido) {
      setMensagem(
        `🔒 Essa ação só é liberada no Nível ${acao.nivelRequerido}! Continue jogando para desbloquear.`
      );
      return;
    }

    // Se está liberada: altera a mensagem do robô e ganha XP
    setMensagem(acao.resposta);
    adicionarXP(20);
  };

  // Função para evoluir o robô
  const adicionarXP = (quantidade) => {
    const novoXp = xp + quantidade;
    if (novoXp >= 100) {
      setNivel(nivel + 1);
      setXp(novoXp - 100);
      setMensagem(`🎉 PARABÉNS! O Robôneuro subiu para o NÍVEL ${nivel + 1}! Nova ação liberada!`);
    } else {
      setXp(novoXp);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Cabeçalho com Botão Voltar */}
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.voltar}
            onPress={() => navigation?.goBack()}
          >
            <Text style={styles.voltarText}>← Voltar</Text>
          </TouchableOpacity>
          <Text style={styles.titulo}>Meu Robô</Text>
        </View>

        {/* Card do Robô e Nível */}
        <View style={styles.roboArea}>
          <Text style={styles.robo}>🤖</Text>
          <Text style={styles.nomeRobo}>Robôneuro</Text>

          {/* Badge de Nível */}
          <View style={styles.badgeNivel}>
            <Text style={styles.textoNivel}>NÍVEL {nivel}</Text>
          </View>

          {/* Barra de Progresso / Energia do Nível */}
          <View style={styles.barraContainer}>
            <View style={[styles.barraPreenchida, { width: `${xp}%` }]} />
          </View>
          <Text style={styles.textoXp}>{xp} / 100 XP para o próximo nível</Text>

          {/* Balão de Fala */}
          <View style={styles.balao}>
            <Text style={styles.mensagem}>{mensagem}</Text>
          </View>
        </View>

        {/* Lista de Ações (Liberadas e Bloqueadas) */}
        <View style={styles.interacoes}>
          <Text style={styles.subtitulo}>Ações do Robô</Text>

          {acoes.map((item) => {
            const desbloqueado = nivel >= item.nivelRequerido;

            return (
              <TouchableOpacity
                key={item.id}
                style={[
                  styles.botao,
                  desbloqueado ? styles.botaoAtivo : styles.botaoBloqueado,
                ]}
                onPress={() => executarAcao(item)}
                activeOpacity={0.7}
              >
                <Text style={styles.icone}>
                  {desbloqueado ? item.icone : '🔒'}
                </Text>
                <View style={styles.infoBotao}>
                  <Text
                    style={[
                      styles.textoBotao,
                      !desbloqueado && styles.textoBloqueado,
                    ]}
                  >
                    {item.titulo}
                  </Text>
                  {!desbloqueado && (
                    <Text style={styles.subtextoBloqueado}>
                      Libera no Nível {item.nivelRequerido}
                    </Text>
                  )}
                </View>
              </TouchableOpacity>
            );
          })}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF1D4',
  },
  scrollContent: {
    padding: 20,
    alignItems: 'center',
  },
  header: {
    width: '100%',
    alignItems: 'center',
    marginBottom: 10,
  },
  voltar: {
    alignSelf: 'flex-start',
    backgroundColor: '#FF6B6B',
    paddingHorizontal: 18,
    paddingVertical: 8,
    borderRadius: 10,
    marginBottom: 10,
  },
  voltarText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FF6B6B',
  },
  roboArea: {
    alignItems: 'center',
    marginTop: 5,
    marginBottom: 20,
    width: '100%',
  },
  robo: {
    fontSize: 90,
  },
  nomeRobo: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#444444',
  },
  badgeNivel: {
    backgroundColor: '#FF6B6B',
    paddingHorizontal: 16,
    paddingVertical: 4,
    borderRadius: 20,
    marginTop: 5,
    marginBottom: 10,
  },
  textoNivel: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 14,
  },
  barraContainer: {
    width: '85%',
    height: 16,
    backgroundColor: '#E0E0E0',
    borderRadius: 10,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  barraPreenchida: {
    height: '100%',
    backgroundColor: '#06D6A0', // Verde vibrante e amigável
    borderRadius: 10,
  },
  textoXp: {
    fontSize: 12,
    color: '#666666',
    marginTop: 4,
    marginBottom: 15,
  },
  balao: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderRadius: 20,
    width: '90%',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  mensagem: {
    fontSize: 16,
    color: '#444444',
    textAlign: 'center',
    fontWeight: '500',
  },
  interacoes: {
    width: '100%',
    alignItems: 'center',
  },
  subtitulo: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#444444',
    marginBottom: 12,
  },
  botao: {
    width: '90%',
    paddingVertical: 12,
    paddingHorizontal: 15,
    borderRadius: 15,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  botaoAtivo: {
    backgroundColor: '#FFD166',
    elevation: 2,
  },
  botaoBloqueado: {
    backgroundColor: '#E5E5E5',
    borderWidth: 1,
    borderColor: '#CCCCCC',
  },
  icone: {
    fontSize: 24,
    marginRight: 15,
  },
  infoBotao: {
    flexDirection: 'column',
  },
  textoBotao: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#444444',
  },
  textoBloqueado: {
    color: '#888888',
  },
  subtextoBloqueado: {
    fontSize: 12,
    color: '#AA3333',
    fontWeight: '600',
  },
});