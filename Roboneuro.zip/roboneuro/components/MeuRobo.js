import React, { useState } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';

export default function MeuRobo({ navigation }) {
  const [mensagem, setMensagem] = useState('Olá! Como posso te ajudar hoje?');

  // Status do Robô
  const [bateria, setBateria] = useState(85);
  const [nivel, setNivel] = useState(1);
  const [xp, setXp] = useState(40);

  // Estado de Conexão
  const [conectado, setConectado] = useState(false);

  // Personalização
  const [corRobo, setCorRobo] = useState('#FF6B6B');
  const [acessorio, setAcessorio] = useState('');

  const cores = [
    { id: 'rosa', hex: '#FF6B6B', nome: 'Rosa' },
    { id: 'azul', hex: '#4EA8DE', nome: 'Azul' },
    { id: 'verde', hex: '#06D6A0', nome: 'Verde' },
    { id: 'amarelo', hex: '#FFD166', nome: 'Amarelo' },
    { id: 'roxo', hex: '#9B5DE5', nome: 'Roxo' },
  ];

  const acessorios = [
    { id: 'nenhum', icone: '❌', nome: 'Nenhum' },
    { id: 'oculos', icone: '🕶️', nome: 'Óculos' },
    { id: 'fones', icone: '🎧', nome: 'Fones' },
    { id: 'chapeu', icone: '🎩', nome: 'Chapéu' },
    { id: 'coroa', icone: '👑', nome: 'Coroa' },
  ];

  const acenar = () => setMensagem('Oi! Que bom ver você!');
  const sorrir = () => setMensagem('Estou muito feliz!');
  const cantar = () => setMensagem('Lá lá lá! Vamos cantar juntos!');

  const alternarConexao = () => {
    if (conectado) {
      setConectado(false);
      setMensagem('Robô desconectado.');
    } else {
      setConectado(true);
      setMensagem('🤖 Robô físico conectado com sucesso!');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Cabeçalho */}
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.voltar}
            onPress={() => navigation?.goBack()}
          >
            <Text style={styles.voltarText}>← Voltar</Text>
          </TouchableOpacity>
          <Text style={styles.titulo}>Meu Robô</Text>
        </View>

        {/* 1. STATUS DO ROBÔ E AVATAR NO TOPO */}
        <View style={styles.roboArea}>
          <View style={styles.avatarContainer}>
            <Text style={styles.acessorioOverlay}>{acessorio}</Text>
            <Text style={styles.robo}>🤖</Text>
          </View>

          <Text style={[styles.nomeRobo, { color: corRobo }]}>Robôneuro</Text>

          {/* Cards de Status do Robô (Bateria e Nível/XP) */}
          <View style={styles.gridStatus}>
            <View style={styles.cardStatus}>
              <Text style={styles.iconeStatus}>🔋</Text>
              <Text style={styles.tituloStatus}>Bateria</Text>
              <Text style={styles.valorStatus}>{bateria}%</Text>
            </View>

            <View style={styles.cardStatus}>
              <Text style={styles.iconeStatus}>⭐</Text>
              <Text style={styles.tituloStatus}>Nível {nivel}</Text>
              <View style={styles.barraContainer}>
                <View style={[styles.barraPreenchida, { width: `${xp}%` }]} />
              </View>
              <Text style={styles.subtextoStatus}>{xp}/100 XP</Text>
            </View>
          </View>

          {/* Balão de Fala do Robô */}
          <View style={styles.balao}>
            <Text style={styles.mensagem}>{mensagem}</Text>
          </View>
        </View>

        {/* 2. CONECTAR ROBÔ */}
        <View style={styles.secao}>
          <Text style={styles.subtitulo}>Conexão</Text>
          <View style={styles.cardConexao}>
            <View style={styles.infoConexao}>
              <View
                style={[
                  styles.ledStatus,
                  { backgroundColor: conectado ? '#06D6A0' : '#FF6B6B' },
                ]}
              />
              <Text style={styles.textoConexao}>
                {conectado ? 'Robô Conectado' : 'Robô Desconectado'}
              </Text>
            </View>

            <TouchableOpacity
              style={[
                styles.botaoConectar,
                { backgroundColor: conectado ? '#FF6B6B' : '#06D6A0' },
              ]}
              onPress={alternarConexao}
            >
              <Text style={styles.textoBotaoConectar}>
                {conectado ? 'Desconectar' : 'Conectar'}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* 3. PERSONALIZAR */}
        <View style={styles.secao}>
          <Text style={styles.subtitulo}>Personalizar Visual</Text>

          <Text style={styles.labelSubsecao}>Cores:</Text>
          <View style={styles.coresContainer}>
            {cores.map((cor) => (
              <TouchableOpacity
                key={cor.id}
                style={[
                  styles.bolinhaCor,
                  { backgroundColor: cor.hex },
                  corRobo === cor.hex && styles.corSelecionada,
                ]}
                onPress={() => {
                  setCorRobo(cor.hex);
                  setMensagem(`Adorei minha cor ${cor.nome}!`);
                }}
              />
            ))}
          </View>

          <Text style={styles.labelSubsecao}>Acessórios:</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.acessoriosContainer}>
              {acessorios.map((item) => (
                <TouchableOpacity
                  key={item.id}
                  style={[
                    styles.cardAcessorio,
                    acessorio === item.icone && styles.acessorioSelecionado,
                  ]}
                  onPress={() => {
                    setAcessorio(item.id === 'nenhum' ? '' : item.icone);
                    setMensagem(
                      item.id === 'nenhum'
                        ? 'Sem acessório por enquanto!'
                        : `Que legal esse ${item.nome}!`
                    );
                  }}
                >
                  <Text style={styles.iconeCard}>{item.icone}</Text>
                  <Text style={styles.textoCard}>{item.nome}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>

        {/* 4. COMANDOS */}
        <View style={styles.secao}>
          <Text style={styles.subtitulo}>Comandos</Text>
          <View style={styles.linhaBotoes}>
            <TouchableOpacity style={styles.botaoPequeno} onPress={acenar}>
              <Text style={styles.icone}>👋</Text>
              <Text style={styles.textoBotaoPequeno}>Acenar</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.botaoPequeno} onPress={sorrir}>
              <Text style={styles.icone}>😊</Text>
              <Text style={styles.textoBotaoPequeno}>Humor</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.botaoPequeno} onPress={cantar}>
              <Text style={styles.icone}>🎵</Text>
              <Text style={styles.textoBotaoPequeno}>Cantar</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF1D4',
  },
  scrollContent: {
    padding: 20,
    alignItems: 'center',
  },
  header: {
    width: '100%',
    alignItems: 'center',
    marginBottom: 10,
  },
  voltar: {
    alignSelf: 'flex-start',
    backgroundColor: '#FF6B6B',
    paddingHorizontal: 18,
    paddingVertical: 8,
    borderRadius: 10,
    marginBottom: 10,
  },
  voltarText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FF6B6B',
  },
  roboArea: {
    alignItems: 'center',
    marginTop: 5,
    marginBottom: 15,
    width: '100%',
  },
  avatarContainer: {
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },
  robo: {
    fontSize: 85,
  },
  acessorioOverlay: {
    position: 'absolute',
    top: -5,
    fontSize: 32,
    zIndex: 1,
  },
  nomeRobo: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  gridStatus: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 15,
  },
  cardStatus: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 15,
    marginHorizontal: 4,
    alignItems: 'center',
    elevation: 1,
  },
  iconeStatus: {
    fontSize: 22,
  },
  tituloStatus: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#444444',
    marginTop: 2,
  },
  valorStatus: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#06D6A0',
    marginTop: 4,
  },
  barraContainer: {
    width: '80%',
    height: 10,
    backgroundColor: '#E0E0E0',
    borderRadius: 5,
    overflow: 'hidden',
    marginTop: 6,
  },
  barraPreenchida: {
    height: '100%',
    backgroundColor: '#FFD166',
  },
  subtextoStatus: {
    fontSize: 11,
    color: '#888888',
    marginTop: 2,
  },
  balao: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 20,
    width: '100%',
    alignItems: 'center',
    elevation: 2,
  },
  mensagem: {
    fontSize: 15,
    color: '#444444',
    textAlign: 'center',
  },
  secao: {
    width: '100%',
    marginBottom: 20,
  },
  subtitulo: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#444444',
    marginBottom: 10,
  },
  labelSubsecao: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666666',
    marginTop: 8,
    marginBottom: 6,
  },
  cardConexao: {
    backgroundColor: '#FFFFFF',
    padding: 14,
    borderRadius: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  infoConexao: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ledStatus: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  textoConexao: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#444444',
  },
  botaoConectar: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
  },
  textoBotaoConectar: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    fontSize: 13,
  },
  coresContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 15,
  },
  bolinhaCor: {
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  corSelecionada: {
    borderWidth: 3,
    borderColor: '#444444',
  },
  acessoriosContainer: {
    flexDirection: 'row',
  },
  cardAcessorio: {
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 15,
    marginRight: 10,
    alignItems: 'center',
    minWidth: 70,
  },
  acessorioSelecionado: {
    borderWidth: 2,
    borderColor: '#FF6B6B',
    backgroundColor: '#FFE5E5',
  },
  iconeCard: {
    fontSize: 24,
  },
  textoCard: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#444444',
    marginTop: 4,
  },
  linhaBotoes: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  botaoPequeno: {
    flex: 1,
    backgroundColor: '#FFD166',
    paddingVertical: 12,
    borderRadius: 12,
    marginHorizontal: 4,
    alignItems: 'center',
  },
  icone: {
    fontSize: 22,
  },
  textoBotaoPequeno: {
    fontSize: 13,
    fontWeight: 'bold',
    color: '#444444',
    marginTop: 2,
  },
});