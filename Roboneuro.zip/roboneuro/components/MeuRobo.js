import React, { useState } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';

export default function MeuRobo({ navigation }) {
  const [mensagem, setMensagem] = useState('Olá! Vamos personalizar meu visual?');
  
  // Estados de Configuração do Robô
  const [corRobo, setCorRobo] = useState('#FF6B6B'); // Cor padrão (Vermelho/Rosa)
  const [acessorio, setAcessorio] = useState(''); // Sem acessório no início
  const [volumeSuave, setVolumeSuave] = useState(true);

  // Lista de cores disponíveis para o Robô
  const cores = [
    { id: 'rosa', hex: '#FF6B6B', nome: 'Rosa' },
    { id: 'azul', hex: '#4EA8DE', nome: 'Azul' },
    { id: 'verde', hex: '#06D6A0', nome: 'Verde' },
    { id: 'amarelo', hex: '#FFD166', nome: 'Amarelo' },
    { id: 'roxo', hex: '#9B5DE5', nome: 'Roxo' },
  ];

  // Lista de acessórios
  const acessorios = [
    { id: 'nenhum', icone: '❌', nome: 'Nenhum' },
    { id: 'oculos', icone: '🧢', nome: 'Boné' },
    { id: 'fones', icone: '👒', nome: 'Chapéu' },
    { id: 'chapeu', icone: '🎩', nome: 'Cartola' },
    { id: 'coroa', icone: '👑', nome: 'Coroa' },
  ];

  const acenar = () => setMensagem('Oi! Que bom ver você!');
  const sorrir = () => setMensagem('Estou muito feliz!');
  const cantar = () => setMensagem('Lá lá lá! Vamos cantar juntos!');

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {/* Cabeçalho */}
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.voltar}
            onPress={() => navigation?.goBack()}
          >
            <Text style={styles.voltarText}>← Voltar</Text>
          </TouchableOpacity>
          <Text style={styles.titulo}>Meu Robô</Text>
        </View>

        {/* Área Visual do Robô */}
        <View style={styles.roboArea}>
          <View style={styles.avatarContainer}>
            {/* Robô com Acessório */}
            <Text style={styles.acessorioOverlay}>{acessorio}</Text>
            <Text style={styles.robo}>🤖</Text>
          </View>

          <Text style={[styles.nomeRobo, { color: corRobo }]}>Robôneuro</Text>

          <View style={styles.balao}>
            <Text style={styles.mensagem}>{mensagem}</Text>
          </View>
        </View>

        {/* SEÇÃO 1: Ações Rápidas */}
        <View style={styles.secao}>
          <Text style={styles.subtitulo}>Interagir</Text>
          <View style={styles.linhaBotoes}>
            <TouchableOpacity style={styles.botaoPequeno} onPress={acenar}>
              <Text style={styles.icone}>👋</Text>
              <Text style={styles.textoBotaoPequeno}>Acenar</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.botaoPequeno} onPress={sorrir}>
              <Text style={styles.icone}>😊</Text>
              <Text style={styles.textoBotaoPequeno}>Humor</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.botaoPequeno} onPress={cantar}>
              <Text style={styles.icone}>🎵</Text>
              <Text style={styles.textoBotaoPequeno}>Cantar</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* SEÇÃO 2: Configurações do Visual do Robô */}
        <View style={styles.secao}>
          <Text style={styles.subtitulo}>Cor do Robô</Text>
          <View style={styles.coresContainer}>
            {cores.map((cor) => (
              <TouchableOpacity
                key={cor.id}
                style={[
                  styles.bolinhaCor,
                  { backgroundColor: cor.hex },
                  corRobo === cor.hex && styles.corSelecionada,
                ]}
                onPress={() => {
                  setCorRobo(cor.hex);
                  setMensagem(`Gostou da minha nova cor ${cor.nome}?`);
                }}
              />
            ))}
          </View>
        </View>

        {/* SEÇÃO 3: Acessórios */}
        <View style={styles.secao}>
          <Text style={styles.subtitulo}>Acessórios</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.acessoriosContainer}>
              {acessorios.map((item) => (
                <TouchableOpacity
                  key={item.id}
                  style={[
                    styles.cardAcessorio,
                    acessorio === item.icone && styles.acessorioSelecionado,
                  ]}
                  onPress={() => {
                    setAcessorio(item.id === 'nenhum' ? '' : item.icone);
                    setMensagem(
                      item.id === 'nenhum'
                        ? 'Tirei o acessório!'
                        : `Olha meu novo visual de ${item.nome}!`
                    );
                  }}
                >
                  <Text style={styles.iconeCard}>{item.icone}</Text>
                  <Text style={styles.textoCard}>{item.nome}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>

        {/* SEÇÃO 4: Ajuste Sensorial (Som) */}
        <View style={styles.secao}>
          <Text style={styles.subtitulo}>Ajuste Sensorial</Text>
          <TouchableOpacity
            style={styles.botaoConfig}
            onPress={() => {
              setVolumeSuave(!volumeSuave);
              setMensagem(
                !volumeSuave
                  ? 'Modo de som suave ativado! 🔊'
                  : 'Som normal ativado!'
              );
            }}
          >
            <Text style={styles.icone}>{volumeSuave ? '🔈' : '🔊'}</Text>
            <View style={styles.infoConfig}>
              <Text style={styles.textoBotao}>Som Suave</Text>
              <Text style={styles.subtextoConfig}>
                {volumeSuave ? 'Ativado (Sons calmos)' : 'Normal'}
              </Text>
            </View>
          </TouchableOpacity>
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF1D4',
  },
  scrollContent: {
    padding: 20,
    alignItems: 'center',
  },
  header: {
    width: '100%',
    alignItems: 'center',
    marginBottom: 10,
  },
  voltar: {
    alignSelf: 'flex-start',
    backgroundColor: '#FF6B6B',
    paddingHorizontal: 18,
    paddingVertical: 8,
    borderRadius: 10,
    marginBottom: 10,
  },
  voltarText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FF6B6B',
  },
  roboArea: {
    alignItems: 'center',
    marginTop: 10,
    marginBottom: 20,
    width: '100%',
  },
  avatarContainer: {
    position: 'relative',
    alignItems: 'center',
    justify: 'center',
  },
  robo: {
    fontSize: 90,
  },
  acessorioOverlay: {
    position: 'absolute',
    top: -5,
    fontSize: 35,
    zIndex: 1,
  },
  nomeRobo: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  balao: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 20,
    width: '90%',
    alignItems: 'center',
    elevation: 2,
  },
  mensagem: {
    fontSize: 16,
    color: '#444444',
    textAlign: 'center',
  },
  secao: {
    width: '100%',
    marginBottom: 20,
  },
  subtitulo: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#444444',
    marginBottom: 10,
  },
  linhaBotoes: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  botaoPequeno: {
    flex: 1,
    backgroundColor: '#FFD166',
    paddingVertical: 10,
    borderRadius: 12,
    marginHorizontal: 4,
    alignItems: 'center',
  },
  textoBotaoPequeno: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#444444',
    marginTop: 2,
  },
  coresContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 15,
  },
  bolinhaCor: {
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  corSelecionada: {
    borderWidth: 3,
    borderColor: '#444444',
  },
  acessoriosContainer: {
    flexDirection: 'row',
  },
  cardAcessorio: {
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 15,
    marginRight: 10,
    alignItems: 'center',
    minWidth: 70,
  },
  acessorioSelecionado: {
    borderWidth: 2,
    borderColor: '#FF6B6B',
    backgroundColor: '#FFE5E5',
  },
  iconeCard: {
    fontSize: 24,
  },
  textoCard: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#444444',
    marginTop: 4,
  },
  botaoConfig: {
    width: '100%',
    backgroundColor: '#FFFFFF',
    padding: 12,
    borderRadius: 15,
    flexDirection: 'row',
    alignItems: 'center',
  },
  infoConfig: {
    marginLeft: 12,
  },
  icone: {
    fontSize: 24,
  },
  textoBotao: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#444444',
  },
  subtextoConfig: {
    fontSize: 12,
    color: '#666666',
  },
});