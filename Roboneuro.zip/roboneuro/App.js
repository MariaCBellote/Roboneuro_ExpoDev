import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Login from './components/Login';
import TelaInicio from './components/TelaInicial';
import Configuracao from './components/Configuracao';
import MeuRobo from './components/MeuRobo';
// import Jogos from './components/Jogos';
// import Atividades from './components/Atividades';
import Progresso from './components/Progresso';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">

        <Stack.Screen
          name="Login"
          component={Login}
          options={{ headerShown: false }}
        />

        <Stack.Screen
          name="Inicio"
          component={TelaInicio}
          options={{ headerShown: false }}
        />

        <Stack.Screen
          name="MeuRobo"
          component={MeuRobo}
          options={{ headerShown: false }}
        />

        <Stack.Screen
          name="Configuracoes"
          component={Configuracao}
          options={{ headerShown: false }}
        />
        
      <Stack.Screen
          name="Progresso"
          component={Progresso}
          options={{ headerShown: false }}
        />

      </Stack.Navigator>
    </NavigationContainer>
  );
}